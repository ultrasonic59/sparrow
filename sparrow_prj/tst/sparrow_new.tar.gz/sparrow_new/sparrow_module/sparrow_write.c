/*
 * sepia_trk_write.c

 *
 *  Created on: feb 10, 2016
 *      Author: vovag
 */
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/uaccess.h>

///#include "../common_inc/sepia_types.h"
////#include "../common_inc/sepia_params.h"
////#include "../common_inc/sepia_trk_ioctl.h"
#include "sparrow_drv.h"

loff_t curr_lseek=0;
///+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
///extern ed_par_trk_t ed_par_trk;
u8 *t_par_buff;

extern u8 *tmp_par_buff;

ssize_t sparrow_write(struct file *filp, const char *buff,
     size_t count, loff_t *offp)
{
#if 0
loff_t t_lseek=	*offp;
////printk( KERN_INFO "\n == write : [%d][%lx][%lx]\n", count,(long)t_lseek ,(long)curr_lseek);
if(t_lseek==OFFS_PARAM)
{
if(copy_from_user(t_par_buff, buff, count))
	{
	return -EFAULT;
	}
 memcpy(&mod_changed_param,t_par_buff,sizeof(u32));
 tmp_par_buff=t_par_buff+sizeof(u32);
printk( KERN_INFO "\n=== [mod]g_changed_param : %lx\n", mod_changed_param);
mod_set_changed_param();
}

#if 0
if(t_lseek==OFFS_ED_PARAM)
{
if(copy_from_user(&ed_par_trk, buff, count))
	{
	return -EFAULT;
	}
}
#endif
#endif
return count;
}
loff_t sparrow_lseek(struct file *filp, loff_t off, int whence)
{
loff_t newpos=0;
switch(whence)
	{
      case 0: /* SEEK_SET */
        newpos = off;
        break;
      case 1: /* SEEK_CUR */
        newpos = filp->f_pos + off;
        break;
 ///     case 2: /* SEEK_END */
 ///       newpos = dev->size + off;
  ///      break;

      default: /* can't happen */
        return -EINVAL;
    }
if (newpos < 0)
	return -EINVAL;
filp->f_pos = newpos;
curr_lseek=newpos;
////printk( KERN_INFO "\n == mole_trk_lseek[%lx][%lx]\n", (long)newpos,(long)curr_lseek);
return newpos;
}
