#ifndef __SPARROW_CNF_H__
#define __SPARROW_CNF_H__
///=======================
extern const char* VER_TXT;
extern const char* MOD_PATH;

#define UDP_PORT 2000

///========================
#define MAX_FRAME_LEN 60000
#define LEN_OSC	256
#define MAX_OSC_LEN 			LEN_OSC
#define NUM_OSC 			2
///=========================
#endif
